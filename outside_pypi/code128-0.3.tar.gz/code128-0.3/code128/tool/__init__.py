
from .console import main
from .gui import gui_main
