#! /usr/bin/env python3

from code128.tool import main

main()
